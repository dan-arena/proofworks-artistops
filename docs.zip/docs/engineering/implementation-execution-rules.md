# Implementation Execution Rules

## Purpose

This document defines the operational execution rules for AI-assisted implementation execution within ProofWorks.

These rules exist to preserve:

- bounded implementation scope
- architecture integrity
- decomposition integrity
- rollback safety
- reviewability
- deterministic implementation flow

These rules apply to:

- Codex-assisted implementation
- AI-assisted implementation execution
- implementation execution threads
- executable Engineering Task documents

---

## Core Execution Philosophy

AI implementation is:

```text
governed execution assistance
```

NOT:

```text
autonomous engineering authority
```

AI execution must remain:

- bounded
- reviewable
- architecture-compliant
- decomposition-compliant
- rollback-safe
- repository-local

Human review remains mandatory.

---

## Approved Execution Model

The currently approved implementation strategy is:

```text
Single-Task Sequential Implementation
```

Implementation flow:

```text
Task Selection
  ->
Codex Reads Governance Docs From Repository
  ->
Codex Reviews Executable Task Document
  ->
Codex Implements On Active Working Branch
  ->
Human Reviews Git Diff
  ->
Governance Validation
  ->
Acceptance Validation
  ->
Commit
  ->
Next Task
```

Parallel AI implementation is intentionally deferred until implementation governance maturity increases.

---

## Repository-Native Execution Rule

Codex execution must occur against:

```text
the active repository working branch
```

The canonical implementation artifact is:

```text
the git diff
```

NOT:

```text
generated repository archives
zip bundles
detached sandbox outputs
```

Implementation output should consist of:

- repository modifications
- branch-local changes
- reviewable git diffs
- repository-native test execution
- repository-native validation

This preserves:

- git history integrity
- deterministic reviewability
- clean branch workflows
- IDE-native development ergonomics
- local build/test validation
- rollback simplicity

Implementation workflows should remain repository-native whenever possible.

---

## Governance Context Propagation Rule

Codex and integrated AI execution environments MUST explicitly read canonical governance documents directly from the repository before implementation begins.

Governance context is NOT implicitly inherited from:

- orchestration threads
- prior conversation summaries
- wrapper prompts alone
- partial transition context

Implementation execution prompts must explicitly require review of:

```text
/docs/engineering
/docs/architecture
/docs/ux
```

as appropriate for the assigned Task boundary.

The repository is considered:

```text
the canonical governance source of truth
```

for implementation execution.

This preserves:

- governance continuity
- implementation determinism
- repository-native operational context
- implementation explainability
- future execution scalability

---

## Implementation Thread Rules

Implementation execution threads MUST:

- remain repository-local
- remain Story-local
- implement only the currently assigned Task
- stop after Task completion
- await review before proceeding
- preserve decomposition boundaries
- preserve architecture boundaries
- preserve UX governance boundaries

Implementation execution threads MUST NOT:

- expand scope
- implement future Tasks
- introduce speculative abstractions
- redesign architecture
- introduce orchestration systems
- infer undefined behavior
- introduce speculative infrastructure
- modify unrelated files without justification

Implementation execution threads should operate primarily through:

- active repository branches
- IDE-native workflows
- repository-native file modification
- local build/test execution
- git-diff review workflows

rather than detached implementation artifact generation.

---

## Task Boundary Enforcement

Executable Task documents are considered:

```text
the implementation contract
```

Implementation must remain inside the Task boundary.

If ambiguity is encountered:

```text
STOP
```

and escalate through the Coordinator/governance flow rather than improvising behavior.

---

## Review Expectations

Every implementation Task requires human review before continuation.

Review validates:

- architecture compliance
- decomposition compliance
- repository locality
- coding standards compliance
- testing expectations
- implementation simplicity
- operational semantics preservation
- absence of scope creep
- absence of hidden orchestration
- rollback safety

Primary implementation review should occur through:

- git diff review
- IDE-native review workflows
- local repository validation
- local build/test execution

Review should NOT rely primarily on:

- generated repository archives
- detached patch bundles
- sandbox repository exports

---

## Rollback Philosophy

Rollback is treated as:

```text
governance preservation
```

NOT:

```text
implementation failure shame
```

Rollback is expected and acceptable when implementation violates:

- architecture boundaries
- decomposition boundaries
- repository locality
- lifecycle semantics
- operational ownership
- reviewability expectations
- implementation simplicity expectations

especially during AI-assisted implementation.

---

## Repository Locality Rule

Implementation execution MUST preserve:

- repository-local Stories
- repository-local Tasks
- repository-local implementation

Cross-repository implementation is NOT permitted during a Task execution loop unless explicitly authorized by governance review.

---

## Backend Ownership Rule

Implementation MUST preserve:

```text
backend-owned operational cognition
```

Frontend implementations must NOT:

- infer lifecycle transitions
- calculate operational readiness
- calculate escalation state
- enforce lifecycle validity
- own operational truth

Frontend remains presentation-oriented.

---

## Completion Rule

A Task is considered complete only when:

- acceptance checks pass
- required tests pass
- repository builds successfully
- implementation remains within scope
- implementation remains reviewable
- governance validation passes
- human review approves continuation

Completion does NOT authorize automatic continuation into the next Task.

---

## Executable Task Prompt Expectations

Executable Task prompts should explicitly require:

- repository governance document review
- executable Task document review
- branch-local implementation
- git-diff-oriented execution
- stopping after Task completion
- awaiting review before continuation

Task prompts should reinforce:

- repository-local implementation
- bounded execution
- architecture preservation
- decomposition compliance
- rollback-safe implementation

Executable Task prompts must not assume governance context inheritance without explicit repository-document review.

---

## Escalation Rule

If implementation encounters:

- architecture ambiguity
- missing operational semantics
- decomposition conflicts
- repository ownership ambiguity
- governance conflicts
- unclear UX expectations

implementation MUST stop and escalate through the governance chain.

AI execution must never silently invent governance behavior.

---

## Current Approved Initial Execution Target

Approved initial implementation target:

```text
TASK-001A-001-domain-model.md
```

This Task was intentionally selected because it is:

- architecture-safe
- highly reviewable
- low orchestration risk
- rollback-safe
- operationally isolated
- implementation-simple

This Task is intended to validate:

- decomposition quality
- implementation governance quality
- Codex execution quality
- review workflow quality
- repository convention stability